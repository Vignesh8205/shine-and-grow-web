
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import AnimatedCounter from './AnimatedCounter';
import CodingBackground from './CodingBackground';

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Enhanced Coding Background Animation */}
      <CodingBackground />
      
      {/* Floating Geometric Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-r from-primary/20 to-accent/20 rounded-full animate-float blur-sm"></div>
        <div className="absolute top-40 right-20 w-32 h-32 bg-gradient-to-r from-accent/10 to-primary/10 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-20 left-20 w-16 h-16 bg-gradient-to-r from-primary/15 to-accent/15 rounded-full animate-float blur-sm" style={{ animationDelay: '4s' }}></div>
        <div className="absolute bottom-40 right-10 w-24 h-24 bg-gradient-to-r from-accent/15 to-primary/15 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        
        {/* Additional Professional Elements */}
        <div className="absolute top-1/3 left-1/4 w-2 h-2 bg-primary rounded-full animate-pulse"></div>
        <div className="absolute top-2/3 right-1/3 w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-primary rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up text-white">
          Transform Your Career with
          <span className="block bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            TCF Technologies
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-gray-300 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          Master cutting-edge technologies with industry experts. Join thousands of successful graduates in top tech companies.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
          <Link to="/courses">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-lg px-8 py-6 shadow-2xl hover:shadow-blue-500/25 transition-all duration-300"
            >
              Explore Courses
            </Button>
          </Link>
          <Link to="/book-demo">
            <Button 
              size="lg"
              variant="outline"
              className="border-2 border-white/30 text-white hover:bg-white/10 hover:border-white/50 text-lg px-8 py-6 backdrop-blur-sm transition-all duration-300"
            >
              Book Free Demo
            </Button>
          </Link>
        </div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="animate-fade-in-up bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20" style={{ animationDelay: '0.6s' }}>
            <AnimatedCounter end={50000} suffix="+" />
            <p className="text-gray-300 mt-2">Students Trained</p>
          </div>
          <div className="animate-fade-in-up bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20" style={{ animationDelay: '0.8s' }}>
            <AnimatedCounter end={100} suffix="%" />
            <p className="text-gray-300 mt-2">Placement Rate</p>
          </div>
          <div className="animate-fade-in-up bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20" style={{ animationDelay: '1s' }}>
            <AnimatedCounter end={500} suffix="+" />
            <p className="text-gray-300 mt-2">Hiring Partners</p>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="h-6 w-6 text-gray-300" />
      </div>
    </section>
  );
};

export default HeroSection;
