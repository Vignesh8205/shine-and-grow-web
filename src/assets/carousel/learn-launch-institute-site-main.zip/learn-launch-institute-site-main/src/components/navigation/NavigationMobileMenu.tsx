
import React from 'react';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';

interface DropdownItem {
  name: string;
  path?: string;
  scrollTo?: string;
}

interface NavigationMobileMenuProps {
  courses: DropdownItem[];
  internshipOptions: string[];
  careerOptions: string[];
  onCourseClick: (course: DropdownItem) => void;
  onInternshipClick: () => void;
  onCareerClick: () => void;
}

const NavigationMobileMenu = ({ 
  courses, 
  internshipOptions, 
  careerOptions, 
  onCourseClick, 
  onInternshipClick, 
  onCareerClick 
}: NavigationMobileMenuProps) => {
  return (
    <Sheet>
      <SheetTrigger asChild className="md:hidden">
        <Button variant="ghost" size="icon" className="hover:scale-110 transition-transform duration-300">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[300px] sm:w-[400px] animate-slide-in-right">
        <div className="flex flex-col space-y-4 mt-8">
          <Link to="/" className="text-lg hover:text-primary transition-colors hover:translate-x-2 duration-300">
            Home
          </Link>
          <Link to="/about" className="text-lg hover:text-primary transition-colors hover:translate-x-2 duration-300">
            About
          </Link>
          
          <div className="space-y-2">
            <Link to="/courses" className="text-lg font-medium hover:text-primary transition-colors hover:translate-x-2 duration-300">
              Courses
            </Link>
            <div className="pl-4 space-y-2">
              <Link to="/courses" className="block text-muted-foreground hover:text-primary transition-colors font-medium hover:translate-x-1 duration-300">
                View All Courses
              </Link>
              {courses.map((course) => (
                <span 
                  key={course.name} 
                  className="block text-muted-foreground text-sm hover:text-primary transition-colors cursor-pointer hover:translate-x-1 duration-300"
                  onClick={() => onCourseClick(course)}
                >
                  {course.name}
                </span>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <Link to="/internship" className="text-lg font-medium hover:text-primary transition-colors hover:translate-x-2 duration-300">
              Internship
            </Link>
            <div className="pl-4 space-y-2">
              <Link to="/internship" className="block text-muted-foreground hover:text-primary transition-colors font-medium hover:translate-x-1 duration-300">
                View All Internships
              </Link>
              {internshipOptions.map((internship) => (
                <span 
                  key={internship} 
                  className="block text-muted-foreground text-sm hover:text-primary transition-colors cursor-pointer hover:translate-x-1 duration-300"
                  onClick={onInternshipClick}
                >
                  {internship}
                </span>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Link to="/career" className="text-lg font-medium hover:text-primary transition-colors hover:translate-x-2 duration-300">
              Career
            </Link>
            <div className="pl-4 space-y-2">
              <Link to="/career" className="block text-muted-foreground hover:text-primary transition-colors font-medium hover:translate-x-1 duration-300">
                Career Services
              </Link>
              {careerOptions.map((career) => (
                <span 
                  key={career} 
                  className="block text-muted-foreground text-sm hover:text-primary transition-colors cursor-pointer hover:translate-x-1 duration-300"
                  onClick={onCareerClick}
                >
                  {career}
                </span>
              ))}
            </div>
          </div>

          <Link to="/blogs" className="text-lg hover:text-primary transition-colors hover:translate-x-2 duration-300">
            Blogs
          </Link>
          
          <div className="pt-4 space-y-3">
            <Link to="/login">
              <Button variant="outline" className="w-full transition-all duration-300 hover:scale-105">
                Login
              </Button>
            </Link>
            <Link to="/signup">
              <Button className="w-full bg-gradient-to-r from-primary to-accent transition-all duration-300 hover:scale-105">
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default NavigationMobileMenu;
