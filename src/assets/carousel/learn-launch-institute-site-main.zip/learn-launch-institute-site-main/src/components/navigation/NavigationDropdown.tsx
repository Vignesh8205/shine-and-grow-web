
import React from 'react';
import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface DropdownItem {
  name: string;
  path?: string;
  scrollTo?: string;
}

interface NavigationDropdownProps {
  title: string;
  items: DropdownItem[];
  onItemClick: (item: DropdownItem) => void;
  viewAllText: string;
  onViewAllClick: () => void;
}

const NavigationDropdown = ({ title, items, onItemClick, viewAllText, onViewAllClick }: NavigationDropdownProps) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex items-center text-foreground hover:text-primary transition-all duration-300 group hover:scale-105">
          {title} <ChevronDown className="ml-1 h-4 w-4 transition-transform duration-300 group-hover:rotate-180" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 bg-background/95 backdrop-blur border shadow-lg z-50 animate-dropdown-enter">
        <DropdownMenuItem 
          className="cursor-pointer hover:bg-primary/10 font-medium transition-all duration-200 transform hover:scale-105 hover:translate-x-1"
          onClick={onViewAllClick}
        >
          {viewAllText}
        </DropdownMenuItem>
        {items.map((item, index) => (
          <DropdownMenuItem 
            key={item.name}
            className="cursor-pointer hover:bg-primary/10 transition-all duration-200 transform hover:scale-105 hover:translate-x-1 animate-dropdown-item"
            style={{ animationDelay: `${index * 30}ms` }}
            onClick={() => onItemClick(item)}
          >
            {item.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default NavigationDropdown;
