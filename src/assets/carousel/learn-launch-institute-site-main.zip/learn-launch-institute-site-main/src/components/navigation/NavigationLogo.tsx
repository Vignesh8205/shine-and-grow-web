
import React from 'react';
import { Link } from 'react-router-dom';

const NavigationLogo = () => {
  return (
    <Link to="/" className="flex items-center space-x-3 hover:scale-105 transition-transform duration-300">
      <img 
        src="/lovable-uploads/0ca2fd12-8959-4098-9f02-048dfd6458f2.png" 
        alt="TCF Technologies Logo"
        className="h-10 w-auto"
      />
      <h1 className="text-xl font-bold text-foreground">
        Technologies
      </h1>
    </Link>
  );
};

export default NavigationLogo;
