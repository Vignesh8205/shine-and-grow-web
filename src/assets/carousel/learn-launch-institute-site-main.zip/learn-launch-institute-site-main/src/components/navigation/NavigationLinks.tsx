
import React from 'react';
import { Link } from 'react-router-dom';

const NavigationLinks = () => {
  return (
    <>
      <Link to="/" className="text-foreground hover:text-primary transition-all duration-300 hover:scale-105 relative group">
        Home
        <span className="absolute inset-x-0 -bottom-1 h-0.5 bg-gradient-to-r from-primary to-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
      </Link>
      <Link to="/about" className="text-foreground hover:text-primary transition-all duration-300 hover:scale-105 relative group">
        About
        <span className="absolute inset-x-0 -bottom-1 h-0.5 bg-gradient-to-r from-primary to-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
      </Link>
      <Link to="/blogs" className="text-foreground hover:text-primary transition-all duration-300 hover:scale-105 relative group">
        Blogs
        <span className="absolute inset-x-0 -bottom-1 h-0.5 bg-gradient-to-r from-primary to-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
      </Link>
      <Link to="/refer-earn" className="text-foreground hover:text-primary transition-all duration-300 hover:scale-105 relative group">
        Refer & Earn
        <span className="absolute inset-x-0 -bottom-1 h-0.5 bg-gradient-to-r from-primary to-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
      </Link>
    </>
  );
};

export default NavigationLinks;
