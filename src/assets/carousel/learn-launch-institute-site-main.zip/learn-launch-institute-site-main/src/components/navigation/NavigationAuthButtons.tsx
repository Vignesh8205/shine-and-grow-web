
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const NavigationAuthButtons = () => {
  return (
    <div className="hidden md:flex items-center space-x-4">
      <Link to="/login">
        <Button 
          variant="ghost" 
          className="hover:bg-primary/10 transition-all duration-300 hover:scale-105"
        >
          Login
        </Button>
      </Link>
      <Link to="/signup">
        <Button 
          className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
        >
          Sign Up
        </Button>
      </Link>
    </div>
  );
};

export default NavigationAuthButtons;
