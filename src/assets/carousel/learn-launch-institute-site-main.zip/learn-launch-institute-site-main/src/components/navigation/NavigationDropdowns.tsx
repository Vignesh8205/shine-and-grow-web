
import React from 'react';
import { useNavigate } from 'react-router-dom';
import NavigationDropdown from './NavigationDropdown';

const NavigationDropdowns = () => {
  const navigate = useNavigate();

  const courses = [
    { name: 'Full Stack Development', path: '/courses', scrollTo: 'full-stack' },
    { name: 'MERN Stack', path: '/courses', scrollTo: 'full-stack' },
    { name: 'Python FullStack', path: '/courses', scrollTo: 'full-stack' },
    { name: 'JAVA FullStack', path: '/courses', scrollTo: 'full-stack' },
    { name: 'Data Science', path: '/courses', scrollTo: 'data-science' },
    { name: 'AWS - DevOps', path: '/courses', scrollTo: 'devops' },
    { name: 'Software Testing', path: '/courses', scrollTo: 'testing' },
    { name: 'Java Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'Python Development', path: '/courses', scrollTo: 'programming' },
    { name: 'C Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'C++ Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'SQL Database', path: '/courses', scrollTo: 'database' },
    { name: 'Artificial Intelligence', path: '/courses', scrollTo: 'ai-ml' },
    { name: 'Machine Learning', path: '/courses', scrollTo: 'ai-ml' }
  ];

  const internshipOptions = [
    'Full Stack Development Intern',
    'Data Science Intern',
    'Java Developer Intern',
    'AI/ML Research Intern',
    'Python Developer Intern',
    'Frontend Developer Intern'
  ];

  const careerOptions = [
    'Job Placement Assistance',
    'Career Counseling',
    'Resume Building',
    'Interview Preparation',
    'Industry Connections',
    'Salary Negotiation'
  ];

  const handleCourseClick = (course: any) => {
    navigate('/courses');
    // Wait for navigation to complete, then scroll and filter
    setTimeout(() => {
      // Trigger filter change
      const filterEvent = new CustomEvent('courseFilterChange', { 
        detail: { filter: course.scrollTo } 
      });
      window.dispatchEvent(filterEvent);
      
      // Scroll to courses section
      const coursesSection = document.getElementById('courses');
      if (coursesSection) {
        coursesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleInternshipClick = () => {
    navigate('/internship');
  };

  const handleCareerClick = () => {
    navigate('/career');
  };

  const handleCoursesViewAll = () => {
    navigate('/courses');
  };

  return (
    <>
      {/* Courses Dropdown */}
      <NavigationDropdown
        title="Courses"
        items={courses}
        onItemClick={handleCourseClick}
        viewAllText="View All Courses"
        onViewAllClick={handleCoursesViewAll}
      />

      {/* Internship Dropdown */}
      <NavigationDropdown
        title="Internship"
        items={internshipOptions.map(name => ({ name }))}
        onItemClick={handleInternshipClick}
        viewAllText="View All Internships"
        onViewAllClick={handleInternshipClick}
      />

      {/* Career Dropdown */}
      <NavigationDropdown
        title="Career"
        items={careerOptions.map(name => ({ name }))}
        onItemClick={handleCareerClick}
        viewAllText="Career Services"
        onViewAllClick={handleCareerClick}
      />
    </>
  );
};

export default NavigationDropdowns;
