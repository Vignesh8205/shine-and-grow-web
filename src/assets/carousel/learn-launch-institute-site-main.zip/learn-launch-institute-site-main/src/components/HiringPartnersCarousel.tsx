
import React from 'react';

const HiringPartnersCarousel = () => {
  const partners = [
    'TCS', 'Infosys', 'HCL', 'Tech Mahindra', 'PayPal', 'Capgemini', 
    'Accenture', 'Wipro', 'Cognizant', 'IBM', 'Microsoft', 'Amazon',
    'Google', 'Deloitte', 'Oracle', 'Salesforce', 'Adobe', 'Intel',
    'Cisco', 'HP', 'Dell', 'Nvidia', 'Samsung', 'LG', 'Sony',
    'Philips', 'Siemens', 'GE', 'Bosch', 'Schneider Electric',
    'L&T Technology Services', 'Mahindra Tech', 'Bajaj Finserv',
    'HDFC Bank', 'ICICI Bank', 'Axis Bank', 'Kotak Mahindra',
    'Yes Bank', 'Federal Bank', 'SBI', 'Paytm', 'PhonePe',
    'Swiggy', 'Zomato', 'Flipkart', 'Myntra', 'BigBasket',
    'Ola', 'Uber', 'RedBus', 'MakeMyTrip'
  ];

  // Duplicate the array for seamless infinite scroll
  const duplicatedPartners = [...partners, ...partners];

  return (
    <div className="w-full overflow-hidden bg-background py-8">
      <div className="flex animate-scroll">
        {duplicatedPartners.map((partner, index) => (
          <div
            key={`${partner}-${index}`}
            className="flex-shrink-0 mx-8 px-6 py-3 bg-card border rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300"
          >
            <span className="text-sm font-medium text-foreground whitespace-nowrap">
              {partner}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HiringPartnersCarousel;
