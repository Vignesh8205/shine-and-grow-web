
import React from 'react';
import { Button } from '@/components/ui/button';

interface CourseFilterProps {
  activeFilter: string;
  onFilterChange: (filter: string) => void;
}

const CourseFilter = ({ activeFilter, onFilterChange }: CourseFilterProps) => {
  const filters = [
    { id: 'all', label: 'All Courses' },
    { id: 'full-stack', label: 'Full Stack' },
    { id: 'programming', label: 'Programming' },
    { id: 'data-science', label: 'Data Science' },
    { id: 'ai-ml', label: 'AI/ML' },
    { id: 'database', label: 'Database' }
  ];

  return (
    <div className="flex flex-wrap gap-3 justify-center mb-12">
      {filters.map((filter) => (
        <Button
          key={filter.id}
          variant={activeFilter === filter.id ? "default" : "outline"}
          onClick={() => onFilterChange(filter.id)}
          className={`transition-all duration-300 transform hover:scale-105 ${
            activeFilter === filter.id 
              ? 'bg-gradient-to-r from-primary to-accent text-white shadow-lg' 
              : 'hover:bg-primary/10'
          }`}
        >
          {filter.label}
        </Button>
      ))}
    </div>
  );
};

export default CourseFilter;
