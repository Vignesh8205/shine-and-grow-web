
import React from 'react';
import AnimatedCounter from './AnimatedCounter';
import CircularProgress from './CircularProgress';
import HiringPartnersCarousel from './HiringPartnersCarousel';
import { Users, BookOpen, Award, TrendingUp, Building, Headphones, ProjectorIcon, UserCheck } from 'lucide-react';

const StatsSection = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4">
        {/* Why Choose TCF Technologies */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Why Choose <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">TCF Technologies?</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're not just another training institute. We're your partners in building a successful tech career with industry-relevant skills and real-world experience.
          </p>
        </div>

        {/* Enhanced Features Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          <div className="text-center bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <Award className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={100} suffix="+" />
            <p className="text-muted-foreground mt-2">Industry Experts</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={50} suffix="+" />
            <p className="text-muted-foreground mt-2">Course Modules</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <ProjectorIcon className="h-12 w-12 text-primary mx-auto mb-4" />
            <div className="font-bold text-3xl text-primary">Final Year</div>
            <p className="text-muted-foreground mt-2">Projects Available</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <UserCheck className="h-12 w-12 text-primary mx-auto mb-4" />
            <div className="font-bold text-3xl text-primary">HR</div>
            <p className="text-muted-foreground mt-2">Internships</p>
          </div>
        </div>

        {/* Services Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <ProjectorIcon className="h-16 w-16 text-primary mb-4" />
            <h3 className="text-2xl font-bold mb-4">Final Year Projects</h3>
            <p className="text-muted-foreground mb-4">
              We offer comprehensive final year project guidance across all departments with industry-standard implementations.
            </p>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Computer Science & Engineering
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Information Technology
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Electronics & Communication
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Mechanical Engineering
              </li>
            </ul>
          </div>
          
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <UserCheck className="h-16 w-16 text-primary mb-4" />
            <h3 className="text-2xl font-bold mb-4">Department-wise Internships</h3>
            <p className="text-muted-foreground mb-4">
              Get hands-on experience with our specialized internship programs tailored for different engineering domains.
            </p>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Software Development Internships
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Data Science & Analytics
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Web Development & Design
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                AI/ML Research Projects
              </li>
            </ul>
          </div>
        </div>

        {/* Where Our Students Get Placed */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Where Our Students Get <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Placed</span>
          </h2>
        </div>

        {/* Hiring Partners Carousel */}
        <div className="mb-20">
          <HiringPartnersCarousel />
        </div>

        {/* Additional Animated Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-16">
          <div className="text-center bg-white rounded-xl p-6 shadow-lg">
            <Users className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={50000} suffix="+" />
            <p className="text-muted-foreground mt-2">Students Trained</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg">
            <Users className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={500} suffix="+" />
            <p className="text-muted-foreground mt-2">Mentors</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg">
            <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={30} suffix="+" />
            <p className="text-muted-foreground mt-2">Courses Offered</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg">
            <Award className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={100} suffix="%" />
            <p className="text-muted-foreground mt-2">Placement Rate</p>
          </div>
          <div className="text-center bg-white rounded-xl p-6 shadow-lg">
            <Building className="h-12 w-12 text-primary mx-auto mb-4" />
            <AnimatedCounter end={500} suffix="+" />
            <p className="text-muted-foreground mt-2">Hiring Partners</p>
          </div>
        </div>

        {/* Circular Progress Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          <CircularProgress 
            percentage={72} 
            label="Student Satisfaction" 
            value="4.8/5 Rating"
          />
          <CircularProgress 
            percentage={78} 
            label="Course Completion" 
            value="High Engagement"
          />
          <CircularProgress 
            percentage={84} 
            label="Job Readiness" 
            value="Industry Ready"
          />
          <CircularProgress 
            percentage={100} 
            label="Placement Success" 
            value="Career Growth"
          />
          <CircularProgress 
            percentage={96} 
            label="Alumni Network" 
            value="Global Reach"
          />
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
