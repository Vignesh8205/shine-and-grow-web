
import React from 'react';
import { Instagram, Facebook, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-background border-t py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-4">
              TCF Technologies
            </h3>
            <p className="text-muted-foreground mb-4">
              Empowering the next generation of tech professionals with industry-relevant skills and real-world experience through innovative training programs.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://www.facebook.com/tcftechnologys" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a 
                href="https://www.twitter.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a 
                href="https://www.linkedin.com/company/tcf-technologies-training/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a 
                href="https://www.instagram.com/tcf_technologies/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="/" className="hover:text-primary transition-colors">Home</a></li>
              <li><a href="/about" className="hover:text-primary transition-colors">About Us</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">Courses</a></li>
              <li><a href="/internship" className="hover:text-primary transition-colors">Internship</a></li>
              <li><a href="/career" className="hover:text-primary transition-colors">Career</a></li>
              <li><a href="/blogs" className="hover:text-primary transition-colors">Blogs</a></li>
              <li><a href="/refer-earn" className="hover:text-primary transition-colors">Refer & Earn</a></li>
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h4 className="font-bold mb-4">Popular Courses</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="/courses" className="hover:text-primary transition-colors">Full Stack Development</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">MERN Stack</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">Python FullStack</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">JAVA FullStack</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">Data Science</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">AWS - DevOps</a></li>
              <li><a href="/courses" className="hover:text-primary transition-colors">Software Testing</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold mb-4">Contact Info</h4>
            <div className="space-y-2 text-muted-foreground">
              <p className="font-semibold text-foreground">TCF Technologies</p>
              <p>9/5, 4th St, Railway Colony,</p>
              <p>Aminjikarai, Chennai,</p>
              <p>Tamil Nadu 600029</p>
              <p>Phone: +91 90803 03212</p>
              <p>Email: <a href="mailto:tcftechnologies.contact@gmail.com" className="text-primary hover:underline">tcftechnologies.contact@gmail.com</a></p>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; {currentYear} TCF Technologies. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-primary transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
