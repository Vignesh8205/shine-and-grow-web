
import React from 'react';

const HiringPartnersMarquee = () => {
  const partners = [
    'TCS', 'Infosys', 'Wipro', 'HCL', 'Tech Mahindra', 'Cognizant', 
    'Accenture', 'IBM', 'Microsoft', 'Google', 'Amazon', 'Meta',
    'Capgemini', 'Deloitte', 'KPMG', 'PwC', 'EY', 'Oracle'
  ];

  return (
    <section className="py-16 bg-muted/30 overflow-hidden">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Our <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Hiring Partners</span>
        </h2>
        
        <div className="relative">
          {/* Gradient overlays for smooth fade effect */}
          <div className="absolute left-0 top-0 w-20 h-full bg-gradient-to-r from-background to-transparent z-10"></div>
          <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-background to-transparent z-10"></div>
          
          {/* Marquee container */}
          <div className="marquee-container">
            <div className="marquee-content">
              {partners.concat(partners).map((partner, index) => (
                <div
                  key={`${partner}-${index}`}
                  className="inline-flex items-center justify-center min-w-[200px] h-16 mx-8 bg-card rounded-lg shadow-sm border hover:shadow-md transition-shadow duration-300"
                >
                  <span className="text-lg font-semibold text-foreground px-4">
                    {partner}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CSS Animation */}
      <style>
        {`
          .marquee-container {
            overflow: hidden;
            white-space: nowrap;
          }
          
          .marquee-content {
            display: inline-block;
            animation: marquee 30s linear infinite;
          }
          
          @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
          
          .marquee-content:hover {
            animation-play-state: paused;
          }
        `}
      </style>
    </section>
  );
};

export default HiringPartnersMarquee;
