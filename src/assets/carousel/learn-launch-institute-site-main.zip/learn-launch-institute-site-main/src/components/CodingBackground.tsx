import React, { useEffect, useRef } from 'react';

const CodingBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Code elements array
    const codeElements: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      text: string;
      fontSize: number;
      opacity: number;
      color: string;
    }> = [];

    // Code snippets and symbols
    const codeSnippets = [
      'function()', 'const', 'let', 'var', 'if', 'else', 'for', 'while',
      'return', 'class', 'import', 'export', 'async', 'await', 'try', 'catch',
      '{', '}', '(', ')', '[', ']', ';', ':', '=', '+', '-', '*', '/', '&&', '||',
      'React', 'useState', 'useEffect', 'props', 'state', 'component',
      'HTML', 'CSS', 'JavaScript', 'TypeScript', 'Node.js', 'API',
      '<div>', '</div>', '<span>', '<h1>', '<p>', '<button>',
      '.map()', '.filter()', '.reduce()', '.forEach()', '.find()',
      'console.log()', 'document', 'window', 'localStorage'
    ];

    const colors = ['#3b82f6', '#ec4899', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'];

    // Create code elements
    for (let i = 0; i < 40; i++) {
      codeElements.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        text: codeSnippets[Math.floor(Math.random() * codeSnippets.length)],
        fontSize: Math.random() * 8 + 10,
        opacity: Math.random() * 0.3 + 0.1,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }

    // Animation loop
    const animate = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.02)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      codeElements.forEach(element => {
        // Update position
        element.x += element.vx;
        element.y += element.vy;

        // Bounce off edges
        if (element.x <= 0 || element.x >= canvas.width) {
          element.vx *= -1;
        }
        if (element.y <= 0 || element.y >= canvas.height) {
          element.vy *= -1;
        }

        // Keep elements in bounds
        element.x = Math.max(0, Math.min(canvas.width, element.x));
        element.y = Math.max(0, Math.min(canvas.height, element.y));

        // Draw element
        ctx.font = `${element.fontSize}px 'Fira Code', 'Monaco', 'Menlo', monospace`;
        ctx.fillStyle = element.color;
        ctx.globalAlpha = element.opacity;
        ctx.fillText(element.text, element.x, element.y);
      });

      ctx.globalAlpha = 1;
      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none opacity-30"
      style={{ background: 'transparent' }}
    />
  );
};

export default CodingBackground;
