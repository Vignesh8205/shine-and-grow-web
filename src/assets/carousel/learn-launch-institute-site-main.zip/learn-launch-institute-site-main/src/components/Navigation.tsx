
import React, { useState } from 'react';
import AuthModal from './AuthModal';
import NavigationLogo from './navigation/NavigationLogo';
import NavigationLinks from './navigation/NavigationLinks';
import NavigationDropdowns from './navigation/NavigationDropdowns';
import NavigationAuthButtons from './navigation/NavigationAuthButtons';
import NavigationMobileMenu from './navigation/NavigationMobileMenu';

const Navigation = () => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  // Data for mobile menu
  const courses = [
    { name: 'Full Stack Development', path: '/courses', scrollTo: 'full-stack' },
    { name: 'Java Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'Python Development', path: '/courses', scrollTo: 'programming' },
    { name: 'C Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'C++ Programming', path: '/courses', scrollTo: 'programming' },
    { name: 'SQL Database', path: '/courses', scrollTo: 'database' },
    { name: 'Artificial Intelligence', path: '/courses', scrollTo: 'ai-ml' },
    { name: 'Machine Learning', path: '/courses', scrollTo: 'ai-ml' },
    { name: 'Data Science', path: '/courses', scrollTo: 'data-science' },
    { name: 'Data Analytics', path: '/courses', scrollTo: 'data-science' }
  ];

  const internshipOptions = [
    'Full Stack Development Intern',
    'Data Science Intern',
    'Java Developer Intern',
    'AI/ML Research Intern',
    'Python Developer Intern',
    'Frontend Developer Intern'
  ];

  const careerOptions = [
    'Job Placement Assistance',
    'Career Counseling',
    'Resume Building',
    'Interview Preparation',
    'Industry Connections',
    'Salary Negotiation'
  ];

  // Mobile menu handlers
  const handleCourseClick = (course: any) => {
    // Same logic as in NavigationDropdowns
    setTimeout(() => {
      const filterEvent = new CustomEvent('courseFilterChange', { 
        detail: { filter: course.scrollTo } 
      });
      window.dispatchEvent(filterEvent);
      
      const coursesSection = document.getElementById('courses');
      if (coursesSection) {
        coursesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleInternshipClick = () => {
    // Navigation handled by NavigationMobileMenu
  };

  const handleCareerClick = () => {
    // Navigation handled by NavigationMobileMenu
  };

  return (
    <nav className="fixed top-0 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b animate-fade-in">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <NavigationLogo />

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationLinks />
            <NavigationDropdowns />
          </div>

          {/* Auth Buttons */}
          <NavigationAuthButtons />

          {/* Mobile Menu */}
          <NavigationMobileMenu
            courses={courses}
            internshipOptions={internshipOptions}
            careerOptions={careerOptions}
            onCourseClick={handleCourseClick}
            onInternshipClick={handleInternshipClick}
            onCareerClick={handleCareerClick}
          />
        </div>
      </div>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        mode={authMode}
      />
    </nav>
  );
};

export default Navigation;
