
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Users, Star, Award, BookOpen } from 'lucide-react';
import EnrollmentModal from './EnrollmentModal';
import CourseFilter from './CourseFilter';

const CoursesSection = () => {
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');
  const [filteredCourses, setFilteredCourses] = useState<any[]>([]);

  const courses = [
    {
      id: 1,
      title: 'Full Stack Development',
      description: 'Master modern web development with React, Node.js, MongoDB, and cloud deployment. Build real-world applications from scratch.',
      duration: '6 months',
      level: 'Beginner to Advanced',
      price: '₹99,999',
      originalPrice: '₹1,49,999',
      image: 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=400&h=250&fit=crop',
      skills: ['React', 'Node.js', 'MongoDB', 'Express.js', 'AWS', 'Docker'],
      highlights: ['Live Projects', 'Industry Mentorship', '100% Job Guarantee', 'Portfolio Building'],
      category: 'full-stack',
      students: '5,200+',
      rating: 4.8,
      projects: 8,
      mentor: 'Expert Industry Professionals'
    },
    {
      id: 2,
      title: 'Java Programming Mastery',
      description: 'Comprehensive Java development course covering Core Java, Spring Boot, Hibernate, and enterprise application development.',
      duration: '5 months',
      level: 'Beginner to Advanced',
      price: '₹79,999',
      originalPrice: '₹1,19,999',
      image: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=250&fit=crop',
      skills: ['Core Java', 'Spring Boot', 'Hibernate', 'JSP', 'Microservices', 'REST API'],
      highlights: ['Industry Projects', 'Oracle Certification', 'Job Support', 'Mock Interviews'],
      category: 'programming',
      students: '4,800+',
      rating: 4.7,
      projects: 6,
      mentor: 'Senior Java Architects'
    },
    {
      id: 3,
      title: 'Python Development Bootcamp',
      description: 'Master Python programming from basics to advanced web development, automation, and API development.',
      duration: '4 months',
      level: 'Beginner to Intermediate',
      price: '₹69,999',
      originalPrice: '₹99,999',
      image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=250&fit=crop',
      skills: ['Python', 'Django', 'Flask', 'APIs', 'Web Scraping', 'Automation'],
      highlights: ['Real Projects', 'Automation Scripts', 'Web Development', 'Career Guidance'],
      category: 'programming',
      students: '3,600+',
      rating: 4.6,
      projects: 5,
      mentor: 'Python Experts'
    },
    {
      id: 4,
      title: 'Data Science & Analytics',
      description: 'Complete data science program with Python, Machine Learning, Deep Learning, and advanced analytics tools.',
      duration: '8 months',
      level: 'Intermediate',
      price: '₹1,29,999',
      originalPrice: '₹1,79,999',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=250&fit=crop',
      skills: ['Python', 'TensorFlow', 'Pandas', 'Tableau', 'SQL', 'Statistics'],
      highlights: ['Real Datasets', 'Capstone Projects', 'Industry Tools', 'Placement Support'],
      category: 'data-science',
      students: '2,900+',
      rating: 4.9,
      projects: 10,
      mentor: 'Data Science Leaders'
    },
    {
      id: 5,
      title: 'Artificial Intelligence & ML',
      description: 'Deep dive into AI algorithms, machine learning models, neural networks, and cutting-edge AI applications.',
      duration: '7 months',
      level: 'Advanced',
      price: '₹1,39,999',
      originalPrice: '₹1,99,999',
      image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=250&fit=crop',
      skills: ['Machine Learning', 'Deep Learning', 'NLP', 'Computer Vision', 'TensorFlow', 'PyTorch'],
      highlights: ['AI Projects', 'Research Papers', 'Industry Applications', 'Advanced Algorithms'],
      category: 'ai-ml',
      students: '2,100+',
      rating: 4.8,
      projects: 12,
      mentor: 'AI Research Scientists'
    },
    {
      id: 6,
      title: 'SQL & Database Management',
      description: 'Master database design, advanced SQL queries, database administration, and performance optimization.',
      duration: '3 months',
      level: 'Beginner to Advanced',
      price: '₹49,999',
      originalPrice: '₹79,999',
      image: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=250&fit=crop',
      skills: ['SQL', 'MySQL', 'PostgreSQL', 'Database Design', 'Data Modeling', 'Performance Tuning'],
      highlights: ['Hands-on Practice', 'Real Databases', 'Performance Optimization', 'Industry Projects'],
      category: 'database',
      students: '6,500+',
      rating: 4.5,
      projects: 4,
      mentor: 'Database Architects'
    }
  ];

  useEffect(() => {
    if (activeFilter === 'all') {
      setFilteredCourses(courses);
    } else {
      setFilteredCourses(courses.filter(course => course.category === activeFilter));
    }
  }, [activeFilter]);

  useEffect(() => {
    // Listen for filter changes from navigation
    const handleApplyCourseFilter = (event: any) => {
      setActiveFilter(event.detail.filter);
    };

    window.addEventListener('applyCourseFilter', handleApplyCourseFilter);
    
    return () => {
      window.removeEventListener('applyCourseFilter', handleApplyCourseFilter);
    };
  }, []);

  const handleEnrollClick = (course: any) => {
    setSelectedCourse(course);
    setIsEnrollModalOpen(true);
  };

  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter);
  };

  return (
    <section id="courses" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Courses</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Industry-designed curriculum with hands-on projects, expert mentorship, and guaranteed placement support. 
            Learn from professionals who've built successful careers in top tech companies.
          </p>
        </div>

        <CourseFilter activeFilter={activeFilter} onFilterChange={handleFilterChange} />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course, index) => (
            <Card 
              key={course.id} 
              className="group hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 overflow-hidden bg-card border-0 shadow-md animate-fade-in-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={course.image} 
                  alt={course.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <Badge variant="secondary" className="bg-white/95 text-primary font-semibold">
                    {course.level}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-white">
                    ⭐ {course.rating}
                  </Badge>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <CardHeader className="pb-3">
                <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                  {course.title}
                </CardTitle>
                <p className="text-muted-foreground text-sm leading-relaxed">{course.description}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{course.students}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <BookOpen className="h-4 w-4" />
                    <span>{course.projects} Projects</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Award className="h-4 w-4" />
                    <span>Certificate</span>
                  </div>
                </div>

                <div className="flex items-end justify-between">
                  <div>
                    <span className="text-2xl font-bold text-primary">{course.price}</span>
                    <span className="text-sm text-muted-foreground line-through ml-2">{course.originalPrice}</span>
                  </div>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    Save {Math.round(((parseInt(course.originalPrice.replace(/[₹,]/g, '')) - parseInt(course.price.replace(/[₹,]/g, ''))) / parseInt(course.originalPrice.replace(/[₹,]/g, ''))) * 100)}%
                  </Badge>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Key Skills:</p>
                  <div className="flex flex-wrap gap-1">
                    {course.skills.slice(0, 4).map((skill) => (
                      <Badge key={skill} variant="outline" className="text-xs hover:bg-primary/10 transition-colors">
                        {skill}
                      </Badge>
                    ))}
                    {course.skills.length > 4 && (
                      <Badge variant="outline" className="text-xs">
                        +{course.skills.length - 4} more
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Course Highlights:</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {course.highlights.map((highlight) => (
                      <li key={highlight} className="flex items-center">
                        <span className="w-1.5 h-1.5 bg-gradient-to-r from-primary to-accent rounded-full mr-2"></span>
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button 
                  className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                  onClick={() => handleEnrollClick(course)}
                >
                  Enroll Now - Limited Time Offer
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">No courses found for the selected category.</p>
          </div>
        )}
      </div>

      <EnrollmentModal 
        isOpen={isEnrollModalOpen}
        onClose={() => setIsEnrollModalOpen(false)}
        course={selectedCourse}
      />
    </section>
  );
};

export default CoursesSection;
