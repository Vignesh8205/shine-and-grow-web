
import React, { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Star } from 'lucide-react';

const StudentFeedback = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const testimonials = [
    {
      id: 1,
      name: 'Priya Sharma',
      course: 'Full Stack Development',
      company: 'TCS',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b4ca3fb7?w=150&h=150&fit=crop&crop=face',
      feedback: 'TCF Technologies transformed my career completely. The hands-on approach and industry mentorship helped me land my dream job at TCS.',
      rating: 5,
      salary: '₹8.5 LPA'
    },
    {
      id: 2,
      name: 'Rahul Kumar',
      course: 'Data Science',
      company: 'Infosys',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      feedback: 'The Data Science course was comprehensive and practical. I got placed in Infosys with a great package. Highly recommend TCF!',
      rating: 5,
      salary: '₹12 LPA'
    },
    {
      id: 3,
      name: 'Sneha Patel',
      course: 'Python Development',
      company: 'Wipro',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
      feedback: 'Excellent teaching methodology and real-world projects. The Python course gave me the confidence to work on complex applications.',
      rating: 5,
      salary: '₹7 LPA'
    },
    {
      id: 4,
      name: 'Amit Singh',
      course: 'Java Programming',
      company: 'Cognizant',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      feedback: 'From zero programming knowledge to getting placed at Cognizant. TCF Technologies made it possible with their structured curriculum.',
      rating: 5,
      salary: '₹6.5 LPA'
    },
    {
      id: 5,
      name: 'Kavya Reddy',
      course: 'AI & Machine Learning',
      company: 'Microsoft',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face',
      feedback: 'The AI course was cutting-edge and industry-relevant. Got an opportunity to work with Microsoft on AI projects.',
      rating: 5,
      salary: '₹18 LPA'
    },
    {
      id: 6,
      name: 'Ravi Gupta',
      course: 'Full Stack Development',
      company: 'Accenture',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
      feedback: 'Amazing support from faculty and placement team. The practical approach helped me understand complex concepts easily.',
      rating: 5,
      salary: '₹9 LPA'
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  // Auto-scroll functionality
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 3 ? 0 : prevIndex + 1
      );
    }, 4000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 3 ? 0 : prevIndex + 1
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 3 : prevIndex - 1
    );
  };

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Student <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Success Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Hear from our successful graduates who transformed their careers with TCF Technologies.
          </p>
        </div>

        <div className="max-w-6xl mx-auto relative">
          {/* Carousel Container */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * (100 / 3)}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-1/3 flex-shrink-0 px-2">
                  <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full">
                    <CardContent className="p-6 flex flex-col h-full">
                      <div className="flex items-center mb-4">
                        <img
                          src={testimonial.image}
                          alt={testimonial.name}
                          className="w-12 h-12 rounded-full object-cover mr-4"
                        />
                        <div>
                          <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                          <p className="text-sm text-muted-foreground">{testimonial.course}</p>
                        </div>
                      </div>

                      <div className="flex mb-3">
                        {renderStars(testimonial.rating)}
                      </div>

                      <p className="text-muted-foreground mb-4 italic flex-grow">
                        "{testimonial.feedback}"
                      </p>

                      <div className="flex justify-between items-center pt-4 border-t mt-auto">
                        <div>
                          <p className="font-medium text-primary">{testimonial.company}</p>
                          <p className="text-sm text-muted-foreground">Current Company</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600">{testimonial.salary}</p>
                          <p className="text-sm text-muted-foreground">Package</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-primary text-primary-foreground rounded-full p-2 hover:bg-primary/90 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-primary text-primary-foreground rounded-full p-2 hover:bg-primary/90 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 space-x-2">
            {Array.from({ length: testimonials.length - 2 }, (_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-primary' : 'bg-muted-foreground/30'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 md:p-12">
            <h3 className="text-3xl font-bold mb-4">Join Our Success Community</h3>
            <p className="text-lg text-muted-foreground mb-6">
              Be the next success story. Start your journey with TCF Technologies today!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">50,000+</div>
                <div className="text-sm text-muted-foreground">Students Placed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">100%</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">₹12 LPA</div>
                <div className="text-sm text-muted-foreground">Avg Package</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="text-sm text-muted-foreground">Hiring Partners</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StudentFeedback;
