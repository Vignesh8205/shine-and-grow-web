
import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';

const Internship = () => {
  const navigate = useNavigate();

  const internships = [
    {
      id: 1,
      title: 'Full Stack Development Intern',
      duration: '3-6 months',
      type: 'Paid',
      stipend: '₹15,000/month',
      skills: ['React', 'Node.js', 'MongoDB'],
      description: 'Work on real client projects and gain hands-on experience in full stack development.',
      requirements: ['Basic knowledge of web development', 'Completed our Full Stack course', 'Portfolio projects']
    },
    {
      id: 2,
      title: 'Data Science Intern',
      duration: '4-6 months',
      type: 'Paid',
      stipend: '₹18,000/month',
      skills: ['Python', 'Machine Learning', 'Data Analysis'],
      description: 'Analyze real datasets and build predictive models for business solutions.',
      requirements: ['Python programming skills', 'Statistics knowledge', 'ML fundamentals']
    },
    {
      id: 3,
      title: 'Java Developer Intern',
      duration: '3-5 months',
      type: 'Paid',
      stipend: '₹12,000/month',
      skills: ['Java', 'Spring Boot', 'Microservices'],
      description: 'Develop enterprise applications using Java and Spring framework.',
      requirements: ['Core Java knowledge', 'OOP concepts', 'Database basics']
    },
    {
      id: 4,
      title: 'AI/ML Research Intern',
      duration: '6 months',
      type: 'Paid',
      stipend: '₹20,000/month',
      skills: ['TensorFlow', 'PyTorch', 'Deep Learning'],
      description: 'Conduct research on cutting-edge AI technologies and publish papers.',
      requirements: ['Advanced ML knowledge', 'Research aptitude', 'Academic background']
    }
  ];

  const handleApplyNow = (internshipId: number) => {
    navigate('/internship-application', { state: { internshipId } });
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Internship <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Programs</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Gain real-world experience with our industry-partnered internship programs. 
              Work on live projects and get mentored by industry experts.
            </p>
          </div>
        </section>

        {/* Internship Listings */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {internships.map((internship) => (
                <Card key={internship.id} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{internship.title}</CardTitle>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {internship.type}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground">{internship.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Duration:</span>
                        <p className="text-muted-foreground">{internship.duration}</p>
                      </div>
                      <div>
                        <span className="font-medium">Stipend:</span>
                        <p className="text-primary font-bold">{internship.stipend}</p>
                      </div>
                    </div>

                    <div>
                      <p className="font-medium mb-2">Required Skills:</p>
                      <div className="flex flex-wrap gap-2">
                        {internship.skills.map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="font-medium mb-2">Requirements:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {internship.requirements.map((req, index) => (
                          <li key={index} className="flex items-center">
                            <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></span>
                            {req}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button 
                      className="w-full bg-gradient-to-r from-primary to-accent"
                      onClick={() => handleApplyNow(internship.id)}
                    >
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Internship Benefits</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">💼</div>
                  <h3 className="text-xl font-bold mb-2">Real Work Experience</h3>
                  <p className="text-muted-foreground">Work on actual client projects and industry challenges</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">👨‍💼</div>
                  <h3 className="text-xl font-bold mb-2">Industry Mentorship</h3>
                  <p className="text-muted-foreground">Get guided by experienced professionals</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-4">🎯</div>
                  <h3 className="text-xl font-bold mb-2">Job Opportunities</h3>
                  <p className="text-muted-foreground">High chances of full-time job offers</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Internship;
