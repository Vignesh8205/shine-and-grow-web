
import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Career = () => {
  const jobOpenings = [
    {
      id: 1,
      title: 'Senior Full Stack Developer',
      department: 'Engineering',
      location: 'Bangalore',
      type: 'Full-time',
      experience: '3-5 years',
      description: 'Lead development of web applications using modern technologies.',
      requirements: ['React', 'Node.js', 'MongoDB', 'AWS']
    },
    {
      id: 2,
      title: 'Data Science Instructor',
      department: 'Education',
      location: 'Hyderabad',
      type: 'Full-time',
      experience: '2-4 years',
      description: 'Teach data science courses and mentor students.',
      requirements: ['Python', 'Machine Learning', 'Teaching Experience', 'PhD preferred']
    },
    {
      id: 3,
      title: 'Java Technical Lead',
      department: 'Engineering',
      location: 'Chennai',
      type: 'Full-time',
      experience: '5-8 years',
      description: 'Lead Java development team and architect enterprise solutions.',
      requirements: ['Java', 'Spring Boot', 'Microservices', 'Team Leadership']
    },
    {
      id: 4,
      title: 'Career Counselor',
      department: 'Student Services',
      location: 'Remote',
      type: 'Full-time',
      experience: '1-3 years',
      description: 'Guide students in their career paths and placement preparation.',
      requirements: ['HR Background', 'Counseling Skills', 'Industry Knowledge']
    }
  ];

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Join Our <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Team</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Be part of TCF Technologies and help shape the future of tech education. 
              We're looking for passionate individuals who want to make a difference.
            </p>
          </div>
        </section>

        {/* Culture Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Work With Us?</h2>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-sm">✓</div>
                    <div>
                      <h3 className="font-semibold">Innovation-Driven Environment</h3>
                      <p className="text-muted-foreground">Work with cutting-edge technologies and methodologies</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-sm">✓</div>
                    <div>
                      <h3 className="font-semibold">Growth Opportunities</h3>
                      <p className="text-muted-foreground">Continuous learning and career advancement</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-sm">✓</div>
                    <div>
                      <h3 className="font-semibold">Competitive Benefits</h3>
                      <p className="text-muted-foreground">Great salary, health insurance, and work-life balance</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-sm">✓</div>
                    <div>
                      <h3 className="font-semibold">Impact-Focused Work</h3>
                      <p className="text-muted-foreground">Help students transform their careers and lives</p>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop"
                  alt="Team collaboration"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Job Openings */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Current Openings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {jobOpenings.map((job) => (
                <Card key={job.id} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-xl">{job.title}</CardTitle>
                    <div className="flex gap-2 text-sm text-muted-foreground">
                      <span>{job.department}</span> • 
                      <span>{job.location}</span> • 
                      <span>{job.type}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{job.description}</p>
                    
                    <div>
                      <p className="font-medium mb-2">Experience Required:</p>
                      <p className="text-sm text-muted-foreground">{job.experience}</p>
                    </div>

                    <div>
                      <p className="font-medium mb-2">Key Requirements:</p>
                      <div className="flex flex-wrap gap-2">
                        {job.requirements.map((req, index) => (
                          <span key={index} className="bg-primary/10 text-primary px-2 py-1 rounded text-xs">
                            {req}
                          </span>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-primary to-accent">
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Application Process */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Application Process</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">1</div>
                <h3 className="font-semibold mb-2">Apply Online</h3>
                <p className="text-sm text-muted-foreground">Submit your application through our portal</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">2</div>
                <h3 className="font-semibold mb-2">Initial Screening</h3>
                <p className="text-sm text-muted-foreground">HR team reviews your profile</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">3</div>
                <h3 className="font-semibold mb-2">Technical Interview</h3>
                <p className="text-sm text-muted-foreground">Technical assessment and team interview</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">4</div>
                <h3 className="font-semibold mb-2">Welcome Aboard</h3>
                <p className="text-sm text-muted-foreground">Join our amazing team</p>
              </div>
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Career;
