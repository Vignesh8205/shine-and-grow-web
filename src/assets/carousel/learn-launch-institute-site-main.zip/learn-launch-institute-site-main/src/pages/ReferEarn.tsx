
import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Gift, Users, DollarSign, Star, Share2, Award } from 'lucide-react';

const ReferEarn = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Refer & <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Earn</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Share the gift of learning with your friends and earn exciting rewards! 
              Join our referral program and get rewarded for every successful referral.
            </p>
            <Button size="lg" className="bg-gradient-to-r from-primary to-accent text-white px-8 py-6 text-lg">
              Start Referring Now
            </Button>
          </div>
        </section>

        {/* How it Works */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-8">
                  <Share2 className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-4">1. Share Your Link</h3>
                  <p className="text-muted-foreground">
                    Share your unique referral link with friends, family, and colleagues who are interested in tech careers.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-8">
                  <Users className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-4">2. Friend Enrolls</h3>
                  <p className="text-muted-foreground">
                    When your friend enrolls in any of our courses using your referral link, they get started on their learning journey.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-8">
                  <Gift className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-4">3. You Earn Rewards</h3>
                  <p className="text-muted-foreground">
                    Receive instant rewards and bonuses for every successful referral. The more you refer, the more you earn!
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Rewards Structure */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Reward Structure</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-green-100 to-green-200 border-green-300">
                <CardHeader className="text-center">
                  <DollarSign className="h-12 w-12 text-green-600 mx-auto mb-2" />
                  <CardTitle className="text-green-800">₹500</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-green-700">Per Basic Course Referral</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-100 to-blue-200 border-blue-300">
                <CardHeader className="text-center">
                  <DollarSign className="h-12 w-12 text-blue-600 mx-auto mb-2" />
                  <CardTitle className="text-blue-800">₹1,000</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-blue-700">Per Advanced Course Referral</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-100 to-purple-200 border-purple-300">
                <CardHeader className="text-center">
                  <DollarSign className="h-12 w-12 text-purple-600 mx-auto mb-2" />
                  <CardTitle className="text-purple-800">₹2,000</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-purple-700">Per Bootcamp Referral</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-100 to-orange-200 border-orange-300">
                <CardHeader className="text-center">
                  <Star className="h-12 w-12 text-orange-600 mx-auto mb-2" />
                  <CardTitle className="text-orange-800">Bonus</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-orange-700">Extra rewards for multiple referrals</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Why Join Our Referral Program?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardContent className="p-8">
                  <Award className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-4">Instant Payouts</h3>
                  <p className="text-muted-foreground">
                    Get your rewards instantly transferred to your account once your referral completes their enrollment.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <Users className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-4">No Limits</h3>
                  <p className="text-muted-foreground">
                    There's no limit to how many people you can refer. The sky's the limit for your earning potential!
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <Share2 className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-4">Easy Sharing</h3>
                  <p className="text-muted-foreground">
                    Share via social media, email, WhatsApp, or any platform of your choice with our easy-to-use tools.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <Gift className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-4">Additional Perks</h3>
                  <p className="text-muted-foreground">
                    Enjoy special discounts on courses, priority support, and exclusive access to new course launches.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary to-accent text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Start Earning?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of satisfied referrers who are already earning with TCF Technologies!
            </p>
            <Button size="lg" variant="secondary" className="text-primary font-bold px-8 py-6 text-lg">
              Get Your Referral Link
            </Button>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default ReferEarn;
