
import React from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

const Blogs = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        <section className="py-16 bg-gradient-to-br from-primary/5 to-accent/5">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Tech Insights & Updates
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Stay updated with the latest trends in technology, programming tutorials, and industry insights from our experts.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Placeholder blog cards */}
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-card rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                  <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg mb-4"></div>
                  <h3 className="text-xl font-semibold mb-2">Blog Post Title {i}</h3>
                  <p className="text-muted-foreground mb-4">
                    Brief description of the blog post content and key takeaways for readers...
                  </p>
                  <div className="flex justify-between items-center text-sm text-muted-foreground">
                    <span>Jan {i}, 2024</span>
                    <span>5 min read</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Blogs;
