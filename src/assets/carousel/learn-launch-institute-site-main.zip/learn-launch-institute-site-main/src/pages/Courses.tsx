
import React, { useEffect, useState } from 'react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import CoursesSection from '@/components/CoursesSection';

const Courses = () => {
  const [courseFilter, setCourseFilter] = useState('all');

  useEffect(() => {
    // Listen for course filter change events from navigation
    const handleCourseFilterChange = (event: any) => {
      setCourseFilter(event.detail.filter);
    };

    window.addEventListener('courseFilterChange', handleCourseFilterChange);
    
    return () => {
      window.removeEventListener('courseFilterChange', handleCourseFilterChange);
    };
  }, []);

  // Pass the filter to CoursesSection via a custom prop or context
  useEffect(() => {
    if (courseFilter !== 'all') {
      // Trigger filter change in CoursesSection
      const filterEvent = new CustomEvent('applyCourseFilter', { 
        detail: { filter: courseFilter } 
      });
      window.dispatchEvent(filterEvent);
    }
  }, [courseFilter]);

  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        <CoursesSection />
      </div>
      <Footer />
    </div>
  );
};

export default Courses;
