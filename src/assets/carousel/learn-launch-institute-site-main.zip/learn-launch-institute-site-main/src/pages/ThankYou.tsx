
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { CheckCircle, Phone, MapPin } from 'lucide-react';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';

const ThankYou = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      <section className="pt-20 pb-16 min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            {/* Success Icon */}
            <div className="mb-8">
              <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
            </div>
            
            {/* Main Message */}
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-foreground">
              Thank You for Your Interest!
            </h1>
            
            <p className="text-xl md:text-2xl mb-4 text-muted-foreground">
              We have received your application.
            </p>
            
            <p className="text-lg mb-8 text-muted-foreground">
              Our academic counselors will get in touch with you shortly!
            </p>
            
            {/* Illustration */}
            <div className="mb-12">
              <div className="relative inline-block">
                <div className="w-64 h-64 mx-auto mb-8 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center">
                  <div className="text-6xl">🎓</div>
                </div>
                
                {/* Floating Achievement Icons */}
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center animate-bounce">
                  <span className="text-xl">🏆</span>
                </div>
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center animate-bounce" style={{ animationDelay: '0.5s' }}>
                  <span className="text-xl">⭐</span>
                </div>
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center animate-bounce" style={{ animationDelay: '1s' }}>
                  <span className="text-xl">📊</span>
                </div>
                <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center animate-bounce" style={{ animationDelay: '1.5s' }}>
                  <span className="text-xl">💼</span>
                </div>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-lg px-8 py-6"
              >
                <MapPin className="mr-2 h-5 w-5" />
                Get Direction
              </Button>
              <Button 
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground text-lg px-8 py-6"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call Now
              </Button>
            </div>
            
            {/* Back to Home */}
            <Link to="/">
              <Button variant="ghost" className="text-muted-foreground hover:text-primary">
                ← Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default ThankYou;
