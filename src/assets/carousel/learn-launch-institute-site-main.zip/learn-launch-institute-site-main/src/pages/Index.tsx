
import React from 'react';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import StatsSection from '@/components/StatsSection';
import CoursesSection from '@/components/CoursesSection';
import HiringPartnersMarquee from '@/components/HiringPartnersMarquee';
import StudentFeedback from '@/components/StudentFeedback';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <StatsSection />
      <CoursesSection />
      <HiringPartnersMarquee />
      <StudentFeedback />
      <Footer />
    </div>
  );
};

export default Index;
